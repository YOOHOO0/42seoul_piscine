#ifndef FT_ABS_H
#define FT_ABS_H

#define ABS(value) (value * ((value >= 0) - (value < 0)))

#endif